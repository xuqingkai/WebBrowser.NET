for(var i in YLYQ.request){
    $('#result').append('<h1>【'+i+'】：'+YLYQ.request[i]+'</h1>');
}