# AppBrowser

### 浏览器壳调用网页js函数
### 网页js调取浏览器壳的方法
### 支持js驱动sql操作sqlite
### 支持跨域异步请求url